# Chap 8 R Script

# Remove all objects
rm(list=ls(all=TRUE))

# The following user-written packages need to be installed first 
# Use install.packages(" ") and then load it with library()
# library(VGAM)                    # It is already installed for Chapter 4
# library(rcompanion)              # It is already installed for Chapter 3
# library(margins)                 # It is already installed for Chapter 3
# library(ggeffects)               # It is already installed for Chapter 2
# library(stargazer)               # It is already installed for Chapter 2

# Import the count dataset
library(foreign)
count <- read.dta("C:/CDA/count.dta")

# Convert variables from integer to numeric so they will work well with ggpredict()
count$educ <- as.numeric(count$educ)
count$wrkfull <- as.numeric(count$wrkfull)
count$maritals <- as.numeric(count$maritals)

attach(count)

# One-predictor Poisson regression model with glm()
PR.1 <- glm(vistzoo ~ educ, family = poisson, data=count)
summary(PR.1)
coef(PR.1)
confint(PR.1)
confint.default(PR.1)
exp(coef(PR.1))
exp(coef(PR.1))*sqrt(diag(vcov(PR.1)))
exp(confint(PR.1))
cbind(exp(coef(PR.1)), exp(confint(PR.1)))

# Testing the overall model using the likelihood ratio test
PR.0 <- glm(vistzoo ~ 1, family = poisson, data=count)
summary(PR.0)
anova(PR.0, PR.1, test="Chisq")
anova(PR.1, update(PR.1, ~1), test="Chisq")

# Pseudo R2 with nagelkerke()
library(rcompanion)
nagelkerke(PR.1)

# Pseudo R2 with equations
LLM1 <- logLik(PR.1)
LL0 <- logLik(PR.0)
McFadden1 <- 1-(LLM1/LL0)
McFadden1
CS1 <- 1-exp(2*(LL0-LLM1)/902)
CS1
NG1 <- CS1/(1-exp(2*LL0/902))
NG1

# AIC and BIC Statistics
AIC(PR.1)
BIC(PR.1)

# Multiple-predictor Poisson regression model with glm()
PR.2 <- glm(vistzoo ~ educ + maritals + female + wrkfull, family = poisson, data=count)
summary(PR.2)
coef(PR.2)
confint(PR.2)
exp(coef(PR.2))
exp(confint(PR.2))
cbind(exp(coef(PR.2)), exp(confint(PR.2)) )
exp(coef(PR.2))*sqrt(diag(vcov(PR.2)))

# Testing the overall model using the likelihood ratio test
anova(PR.2, update(PR.2, ~1), test="Chisq")
anova(PR.0, PR.2, test="Chisq")

# Pseudo R2 with nagelkerke()
nagelkerke(PR.2)

# Pseudo R2 with equations
LLM2 <- logLik(PR.2)
McFadden2 <- 1-(LLM2/LL0)
McFadden2
CS2 <- 1-exp(2*(LL0-LLM2)/902)
CS2
NG2 <- CS2/(1-exp(2*LL0/902))
NG2

# AIC and BIC Statistics
AIC(PR.2)
BIC(PR.2)
AIC(PR.1, PR.2)
BIC(PR.1, PR.2)

# Model comparison with the likelihood ratio test
anova(PR.1, PR.2, test="Chisq")

library(stargazer)
stargazer(PR.1, PR.2, type="text", align=TRUE, out="pr2mod.txt")
stargazer(PR.1, PR.2, type="html", align=TRUE, out="pr2mod.htm")

# Marginal effects: AME
library(margins)
marg.pr <- margins(PR.2)
summary(marg.pr)

# Predicted counts with ggpredict() in ggeffects
library(ggeffects)
pr.ed <- ggpredict(PR.2,terms="educ[12, 14, 16]")
pr.ed
plot(pr.ed)
pr.ew <- ggpredict(PR.2, terms=c("educ[12, 14, 16]","wrkfull"))
pr.ew
plot(pr.ew)

# Multiple-predictor Poisson regression model with vglm() ing VGAM
library(VGAM)
pr.v <- vglm(vistzoo ~ educ + maritals + female + wrkfull, family = poissonff, data=count)
summary(pr.v)
coef(pr.v, matrix = TRUE)
confint(pr.v, matrix = TRUE)
exp(coef(pr.v, matrix = TRUE))
exp(confint(pr.v, matrix = TRUE))
cbind(exp(coef(pr.v, matrix = TRUE)), exp(confint(pr.v, matrix = TRUE)))
exp(coef(pr.v))*sqrt(diag(vcov(pr.v)))

# Pseudo R2 with nagelkerke()
library(rcompanion)
nagelkerke(pr.v)

detach(count)

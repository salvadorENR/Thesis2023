# Chap 13 R Script

# Remove all objects
rm(list = ls(all = TRUE))

# The following user-written packages need to be installed first 
# Use install.packages(" ") and then load it with library()
# library(lme4)                    # It is already installed for Chapter 10
# library(margins)                 # It is already installed for Chapter 3
# library(ggeffects)               # It is already installed for Chapter 2
# library(stargazer)               # It is already installed for Chapter 2
# library(texreg)                  # It is already installed for Chapter 4
# library(glmmTMB)                  
# library(bbmle)     
# library(MASS)                    # It is part of R base distribution
# library(nlme)                    # It is part of R base distribution          

# Import the dataset
library(foreign)
mecount <- read.dta("C:/CDA/mecount.dta")
attach(mecount)
# str(mecount)
# Descriptive statitics
library(sjmisc)
descr(mecount, byabsen, cmathach, bygender, public, csclimate)

library(lme4)
# Unconditional Model/Null model with glmer()
mepois.1 <- glmer(byabsen ~ 1 + (1|SCH_ID), data=mecount, family=poisson, nAGQ=1)
summary(mepois.1)
coef <- fixef(mepois.1)
se <- sqrt(diag(vcov(mepois.1)))
LL <- fixef(mepois.1)-1.96*se
UL <- fixef(mepois.1)+1.96*se
coeftab <- cbind(coef, LL, UL)
coeftab
exp(fixef(mepois.1))
exp(coeftab)
irtab <- cbind(ir=exp(fixef(mepois.1)), IRLL=exp(LL), IRUL=exp(UL))
irtab

confint(mepois.1, method="Wald")
exp(confint(mepois.1, method="Wald"))

mepois.1b <- glmer(byabsen ~ 1 + (1|SCH_ID), data=mecount, family=poisson, nAGQ=7)
summary(mepois.1b)

# Random-intercept model
mepois.2 <- glmer(byabsen ~ cmathach + bygender + (1|SCH_ID), data=mecount, family=poisson, nAGQ=1)
summary(mepois.2)
coef <- fixef(mepois.2)
se <- sqrt(diag(vcov(mepois.2)))
LL <- fixef(mepois.2)-1.96*se
UL <- fixef(mepois.2)+1.96*se
coeftab <- cbind(coef, LL, UL)
coeftab
exp(fixef(mepois.2))
exp(coeftab)
irtab <- cbind(ir=exp(fixef(mepois.2)), IRLL=exp(LL), IRUL=exp(UL))
irtab

confint(mepois.2, method="Wald")
exp(confint(mepois.2, method="Wald"))

anova(mepois.1, mepois.2)

# Random-coefficient model
mepois.3 <- glmer(byabsen ~ cmathach + bygender + (bygender|SCH_ID), data=mecount, family=poisson, nAGQ=1)
summary(mepois.3)
coef <- fixef(mepois.3)
se <- sqrt(diag(vcov(mepois.3)))
LL <- fixef(mepois.3)-1.96*se
UL <- fixef(mepois.3)+1.96*se
coeftab <- cbind(coef, LL, UL)
coeftab
exp(fixef(mepois.3))
exp(coeftab)
irtab <- cbind(ir=exp(fixef(mepois.3)), IRLL=exp(LL), IRUL=exp(UL))
irtab

confint(mepois.3, method="Wald")
exp(confint(mepois.3, method="Wald"))

anova(mepois.2, mepois.3)

# Contextual model/Random-coefficient model with predictor variables in both levels
mepois.4 <- glmer(byabsen ~ cmathach + bygender + public + csclimate + (bygender|SCH_ID), 
                data=mecount, family=poisson, nAGQ=1)
summary(mepois.4)
coef <- fixef(mepois.4)
se <- sqrt(diag(vcov(mepois.4)))
LL <- fixef(mepois.4)-1.96*se
UL <- fixef(mepois.4)+1.96*se
coeftab <- cbind(coef, LL, UL)
coeftab
exp(fixef(mepois.4))
exp(coeftab)
irtab <- cbind(ir=exp(fixef(mepois.4)), IRLL=exp(LL), IRUL=exp(UL))
irtab

confint(mepois.4, method="Wald")
exp(confint(mepois.4, method="Wald"))

anova(mepois.3, mepois.4)

# Model comparisons
anova(mepois.1, mepois.2, mepois.3, mepois.4)

# Marginal effect with margins()
library(margins)
marg <- margins(mepois.4)
summary(marg)

# Marginal effects/Predicted counts with ggpredict() in ggeffects
library(ggeffects)
mepoi4.efpub <- ggpredict(mepois.4, terms=c("csclimate", "public"))
mepoi4.efpub
plot(mepoi4.efpub)

mepoi4.efpub.r <- ggpredict(mepois.4, terms=c("csclimate", "public"), type="re")
mepoi4.efpub.r
plot(mepoi4.efpub.r)

# Presenting the results with stargazer()
library(stargazer)
stargazer(mepois.1, mepois.4, type="text", align=TRUE, out="mepoison.txt")
stargazer(mepois.1, mepois.4, type="html", align=TRUE, out="mepoison.htm")

# Presenting the results with texreg()
library(texreg)
screenreg(list(mepois.1, mepois.4))
htmlreg(list(mepois.1, mepois.4), file="mepoison.doc", doctype=TRUE, html.tag=TRUE, head.tag=TRUE)

# Multilevel Poisson model with glmmTMB()
# install.packages("glmmTMB")
library(glmmTMB)
mepois.4b <- glmmTMB(byabsen ~ cmathach + bygender + public + csclimate + (bygender|SCH_ID), 
                   data=mecount, family=poisson)
summary(mepois.4b)

confint(mepois.4b)
exp(confint(mepois.4b))

# Model comparisons with AICtab()
# install.packages("bbmle")
library(bbmle)
AICtab(mepois.3, mepois.4b)
AICtab(mepois.1, mepois.2, mepois.3, mepois.4b)

# Multilevel Poisson model with glmmPQL()
library(MASS)
library(nlme)
mepois.4c <- glmmPQL(byabsen ~ cmathach + bygender + public + csclimate, 
                   random = ~bygender|SCH_ID, data=mecount, family=poisson)
summary(mepois.4c)
intervals(mepois.4c)
intervals(mepois.4c,which="fixed")

coef <- fixef(mepois.4c)
se <- sqrt(diag(vcov(mepois.4c)))
LL <- fixef(mepois.4c)-1.96*se
UL <- fixef(mepois.4c)+1.96*se
coeftab <- cbind(coef, LL, UL)
coeftab
exp(fixef(mepois.4c))
exp(coeftab)
irtab <- cbind(ir=exp(fixef(mepois.4c)), IRLL=exp(LL), IRUL=exp(UL))
irtab
VarCorr(mepois.4c)

# Multilevel negative binomial model with glmmTMB()
menb.4 <- glmmTMB(byabsen ~ cmathach + bygender + public + csclimate + (bygender|SCH_ID), 
                data=mecount, family=nbinom2)
summary(menb.4)
confint(menb.4)
exp(confint(menb.4))

detach(mecount)

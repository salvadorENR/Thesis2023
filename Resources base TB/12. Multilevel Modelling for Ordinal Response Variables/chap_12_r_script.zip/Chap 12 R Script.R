# Chap 12 R Script

# Remove all objects
rm(list = ls(all = TRUE))

# The following user-written packages need to be installed first 
# Use install.packages(" ") and then load it with library()
# library(ordinal)                 # It is already installed for Chapter 4
# library(ggeffects)               # It is already installed for Chapter 2
# library(texreg)                  # It is already installed for Chapter 4
# library(mixor)

# Import the dataset
library(foreign)
chp12 <- read.dta("C:/CDA/els2002.dta")
chp12 <- chp12[!is.na(chp12$Profmath)&!is.na(chp12$stlang)&!is.na(chp12$public)&!is.na(chp12$sclimate), ]
chp12$Profmath <- factor(chp12$Profmath, ordered=TRUE)
attach(chp12)
table(Profmath)
table(stlang)
mean(sclimate)
table(public)
chp12$csclimat <- sclimate-mean(sclimate, na.rm=TRUE)
summary(chp12$csclimat)

library(ordinal)
# Unconditional model/Null model with clmm()
mpo.1 <- clmm(Profmath ~ 1 + (1|SCH_ID), data=chp12, na.action="na.omit", Hess=TRUE, nAGQ=7)
summary(mpo.1)
coef(mpo.1)
confint(mpo.1)
exp(coef(mpo.1))
exp(confint(mpo.1))

# Random-intercept model
# It may take several minutes to fit the model
mpo.2 <- clmm(Profmath ~ stlang + (1|SCH_ID), data=chp12, Hess=TRUE, nAGQ=7)
summary(mpo.2)
coef(mpo.2)
confint(mpo.2)
cbind(coef(mpo.2),confint(mpo.2))
exp(coef(mpo.2))
exp(confint(mpo.2))
cbind(exp(coef(mpo.2)),exp(confint(mpo.2)))
anova(mpo.1, mpo.2)

# Random-coefficient model
# It may take several minutes to fit the model
mpo.3 <- clmm(Profmath ~ stlang + (stlang|SCH_ID), data=chp12, Hess=TRUE, nAGQ=1)
summary(mpo.3)
coef(mpo.3)
confint(mpo.3)
cbind(coef(mpo.3),confint(mpo.3))
exp(coef(mpo.3))
exp(confint(mpo.3))
cbind(exp(coef(mpo.3)),exp(confint(mpo.3)))
anova(mpo.2, mpo.3)

# Contextual model/Random-coefficient model with predictor variables in both levels
# It may take several minutes (normally around 5 minutes) to fit the model
mpo.4 <- clmm(Profmath ~ stlang + public + csclimat + (stlang|SCH_ID), 
            data=chp12, Hess=TRUE, nAGQ=1)
summary(mpo.4)
coef(mpo.4)
confint(mpo.4)
cbind(coef(mpo.4),confint(mpo.4))
exp(coef(mpo.4))
exp(confint(mpo.4))
cbind(exp(coef(mpo.4)),exp(confint(mpo.4)))
anova(mpo.3, mpo.4)

# Contextual model with cross-level interactions
# It may take several minutes (normally around 5 minutes) to fit the model
mpo.5 <- clmm(Profmath ~ stlang + public + csclimat + public:stlang + csclimat:stlang + (stlang|SCH_ID), 
            data=chp12, Hess=TRUE, nAGQ=1)
summary(mpo.5)
coef(mpo.5)
confint(mpo.5)
cbind(coef(mpo.5),confint(mpo.5))
exp(coef(mpo.5))
exp(confint(mpo.5))
cbind(exp(coef(mpo.5)),exp(confint(mpo.5)))
anova(mpo.4, mpo.5)

# Model comparisons
anova(mpo.1, mpo.2, mpo.3, mpo.4, mpo.5)

# Marginal effects/Predicted probabilities with ggpredict()
# install.packages(emmeans)
# install.packages("ggeffects")
library(ggeffects)
mpo4.clpub <- ggpredict(mpo.4, terms=c("csclimat", "public"))
mpo4.clpub
plot(mpo4.clpub)

# Presenting the results with texreg()
library(texreg)
screenreg(list(mpo.1,mpo.2, mpo.3,mpo.4))
htmlreg(list(mpo.1,mpo.2, mpo.3,mpo.4), file="mpo.doc", doctype=TRUE, html.tag=TRUE, head.tag=TRUE)

# Contextual model/Random-coefficient model with level 2 variables with mixor()
# Install the mixor package by using install.packages("mixor")
# If it was removed from the CRAN repository, download it from the archive
# and then install it from the RStudio pull-down menu.
library(mixor)
# Model with non-adaptive Gauss-Hermite quadrature 
mpo.4b <- mixor(Profmath ~ stlang + public + csclimat, id=SCH_ID, data=chp12, 
              which.random.slope=1, adaptive.quadrature = FALSE, link="logit")
summary(mpo.4b)

# Model with adaptive Gauss-Hermite quadrature 
mpo.4c <- mixor(Profmath ~ stlang + public + csclimat, id=SCH_ID, data=chp12, 
              which.random.slope=1, nAGQ=7, link="logit")
summary(mpo.4c)
coef(mpo.4c)
confint(mpo.4c)
cbind(coef(mpo.4c),confint(mpo.4c))
exp(coef(mpo.4c))
exp(confint(mpo.4c))
cbind(exp(coef(mpo.4c)),exp(confint(mpo.4c)))
cm <- matrix(c(-1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1,0, 0, 0, 0, 0, 0, 1, 0, 0, 0,
               -1,0, 0, 0, 0, 0, 0, 0, 1, 0, 0,-1,0, 0, 0, 0, 0, 0, 0, 0, 1, 0,
               -1,0, 0, 0, 0, 0, 0, 0, 0, 0, 1), ncol=5)
Contrasts(mpo.4c, contrast.matrix = cm)

detach(chp12)

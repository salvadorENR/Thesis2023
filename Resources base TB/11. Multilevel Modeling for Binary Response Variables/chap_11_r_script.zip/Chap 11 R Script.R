# Chap 11 R Script

# Remove all objects
rm(list = ls(all=TRUE))

# The following user-written packages need to be installed first 
# Use install.packages(" ") and then load it with library()
# library(lme4)                    # It is already installed for Chapter 10
# library(margins)                 # It is already installed for Chapter 3
# library(ggeffects)               # It is already installed for Chapter 2
# library(stargazer)               # It is already installed for Chapter 2
# library(ordinal)                 # It is already installed for Chapter 4

# Import the dataset
library(foreign)
chp11 <- read.dta("C:/CDA/els2002.dta")
chp11 <- chp11[!is.na(chp11$Profmath1)&!is.na(chp11$stlang)&!is.na(chp11$public)&!is.na(chp11$sclimate), ]
attach(chp11)
chp11$csclimat <- sclimate-mean(sclimate, na.rm=TRUE)
summary(chp11$csclimat)
table(Profmath1)
table(stlang)
mean(sclimate)
table(public)

library(lme4)
# Unconditional model/Null model with glmer()
melr.1 <- glmer(Profmath1~ + (1|SCH_ID), data=chp11, family=binomial, nAGQ=7)
summary(melr.1)
coef <- fixef(melr.1)
se <- sqrt(diag(vcov(melr.1)))
LL <- fixef(melr.1)-1.96*se
UL <- fixef(melr.1)+1.96*se
coeftab <- cbind(coef, LL, UL)
coeftab
exp(fixef(melr.1))
exp(coeftab)
ortab <- cbind(or=exp(fixef(melr.1)), ORLL=exp(LL), ORUL=exp(UL))
ortab
# confint(melr.1)
confint(melr.1, method="Wald")

# Random-intercept model
melr.2 <- glmer(Profmath1~ stlang + (1|SCH_ID), data=chp11, family=binomial, nAGQ=7)
summary(melr.2)
coef <- fixef(melr.2)
se <- sqrt(diag(vcov(melr.2)))
LL <- fixef(melr.2)-1.96*se
UL <- fixef(melr.2)+1.96*se
coeftab <- cbind(coef, LL, UL)
coeftab
exp(fixef(melr.2))
exp(coeftab)
ortab <- cbind(or=exp(fixef(melr.2)), ORLL=exp(LL), ORUL=exp(UL))
ortab    
# confint(melr.2)
confint(melr.2, method="Wald")

anova(melr.1, melr.2)

# Random-coefficient model
melr.3 <- glmer(Profmath1~ stlang + (stlang|SCH_ID), data=chp11, family=binomial, nAGQ=1)
summary(melr.3)
coef <- fixef(melr.3)
se <- sqrt(diag(vcov(melr.3)))
LL <- fixef(melr.3)-1.96*se
UL <- fixef(melr.3)+1.96*se
coeftab <- cbind(coef, LL, UL)
coeftab
exp(fixef(melr.3))
exp(coeftab)
ortab <- cbind(or=exp(fixef(melr.3)), ORLL=exp(LL), ORUL=exp(UL))
ortab   
confint(melr.3, method="Wald")
anova(melr.2, melr.3)

# Contextual model/Random-coefficient model with predictor variables in both levels
# It may take several minutes to fit the model
melr.4 <- glmer(Profmath1~ stlang + csclimat + public + (stlang|SCH_ID), 
              data=chp11, family=binomial, nAGQ=1)
summary(melr.4)
coef <- fixef(melr.4)
se <- sqrt(diag(vcov(melr.4)))
LL <- fixef(melr.4)-1.96*se
UL <- fixef(melr.4)+1.96*se
coeftab <- cbind(coef, LL, UL)
coeftab
confint(melr.4, method="Wald")
exp(fixef(melr.4))
exp(coeftab)
ortab <- cbind(or=exp(fixef(melr.4)), ORLL=exp(LL), ORUL=exp(UL))
ortab        
anova(melr.3, melr.4)

# Contextual model with cross-level interactions
# It may take several minutes to fit the model
melr.5 <- glmer(Profmath1~ stlang + csclimat + public + public:stlang + 
                csclimat:stlang + (stlang|SCH_ID), data=chp11, family=binomial, nAGQ=1)
summary(melr.5)
coef <- fixef(melr.5)
se <- sqrt(diag(vcov(melr.5)))
LL <- fixef(melr.5)-1.96*se
UL <- fixef(melr.5)+1.96*se
coeftab <- cbind(coef, LL, UL)
coeftab
confint(melr.5, method="Wald")
exp(fixef(melr.5))
exp(coeftab)
ortab <- cbind(or=exp(fixef(melr.5)), ORLL=exp(LL), ORUL=exp(UL))
ortab        
anova(melr.4, melr.5)

# Model comparisons
anova(melr.1, melr.2, melr.3, melr.4, melr.5)

# Marginal effects/Predicted probabilities with ggpredict()
library(ggeffects)
melr.4.pub <- ggpredict(melr.4, terms="public")
melr.4.pub
as.data.frame(melr.4.pub)
plot(melr.4.pub)

me4.efpub <- ggpredict(melr.4, terms=c("csclimat", "public"))
me4.efpub
plot(me4.efpub)

me4.efpub.r <- ggpredict(melr.4, terms=c("csclimat", "public"), type="re")
me4.efpub.r
plot(me4.efpub.r)

# Presenting the results with stargazer()
library(stargazer)
stargazer(melr.1, melr.5, type="text", align=TRUE, out="melr.txt")
stargazer(melr.1, melr.5, type="html", align=TRUE, out="melr.htm")

# Presenting the results with texreg()
library(texreg)
screenreg(list(melr.1, melr.5))
htmlreg(list(melr.1, melr.5), file="melr.doc", doctype=TRUE, html.tag=TRUE, head.tag=TRUE)

# Use the clmm() function in the ordinal package
# Install the ordinal package by using install.package()
library(ordinal)
melr.4b <- clmm(as.factor(Profmath1)~ stlang + csclimat + public + (stlang|SCH_ID), 
              data=chp11, na.action="na.omit", Hess=TRUE, nAGQ=1)
summary(melr.4b)
confint(melr.4b)
cbind(coef(melr.4b), confint(melr.4b))
exp(coef(melr.4b))
exp(confint(melr.4b))
cbind(exp(coef(melr.4b)), exp(confint(melr.4b)))

detach(chp11)

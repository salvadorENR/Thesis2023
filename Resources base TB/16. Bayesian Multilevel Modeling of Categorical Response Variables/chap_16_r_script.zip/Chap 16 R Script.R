# Chap 16 R Script

# Remove all objects
rm(list = ls(all=TRUE))
# The following user-written packages need to be installed first 
# Use install.packages(" ") and then load it with library()
# library(brms)                    # It is already installed for Chapter 14
# library(MCMCglmm)                # It is already installed for Chapter 14
# library(texreg)                  # It is already installed for Chapter 4

# Import the dataset
library(foreign)
els <- read.dta("C:/CDA/els2002.dta")
els <- els[!is.na(els$Profmath1)&!is.na(els$stlang)&!is.na(els$public)&!is.na(els$sclimate), ]
attach(els)
els$csclimat <- sclimate-mean(sclimate, na.rm=TRUE)
summary(els$csclimat)

# Bayesian multilevel logistic regression models
# It may take several minutes to fit the model
library(brms)
melr.brm <- brm(Profmath1~ stlang + csclimat + public + (stlang|SCH_ID), 
              data=els, family=bernoulli, 
              warmup = 500, iter = 2000, 
              cores = 2, chains = 2, seed=123)
summary(melr.brm)
print(melr.brm, digits=3)
coef <- fixef(melr.brm, summary=TRUE)
coef
exp(fixef(melr.brm)[, -2])
save(melr.brm, file = "melrbrm.rda")
plot(melr.brm)
conditional_effects(melr.brm)  

# Present the results with texreg()
library(texreg)
# Customize the extract() function and the createTexreg() function
extract.brmsfit <- function (model,
                             use.HDI = TRUE,
                             HDI.prob = 0.9,
                             include.random = TRUE,
                             include.rsquared = FALSE,
                             include.nobs = TRUE,
                             include.loo.ic = FALSE,
                             reloo = FALSE,
                             include.waic = FALSE,
                             ...) {
  sf <- summary(model, ...)$fixed
  coefnames <- rownames(sf)
  coefs <- sf[, 1]
  se <- sf[, 2]
  ci.low = sf[, 3]
  ci.up = sf[, 4]
  gof <- numeric()
  gof.names <- character()
  gof.decimal <- logical()
  if (isTRUE(include.random) & isFALSE(!nrow(model$ranef))) {
    sr <- summary(model, ...)$random
    sd.names <- character()
    sd.values <- numeric()
    for (i in 1:length(sr)) {
      sd <- sr[[i]][, 1]
      sd.names <- c(sd.names, paste0("SD: ", names(sr)[[i]], ": ", names(sd)))
      sd.values <- c(sd.values, sd)
    }
    gof <- c(gof, sd.values)
    gof.names <- c(gof.names, sd.names)
    gof.decimal <- c(gof.decimal, rep(TRUE, length(sd.values)))
  }
  if (isTRUE(include.nobs)) {
    n <- stats::nobs(model)
    gof <- c(gof, n)
    gof.names <- c(gof.names, "Num. obs.")
    gof.decimal <- c(gof.decimal, FALSE)
  }
  tr <- createTexreg(coef.names = coefnames,
                     coef = coefs,
                     se = se,
                     ci.low = ci.low,
                     ci.up = ci.up,
                     gof.names = gof.names,
                     gof = gof,
                     gof.decimal = gof.decimal)
  return(tr)
}
# Register the function with setMethod()
setMethod("extract", signature = className("brmsfit", "brm"),
          definition = extract.brmsfit)
screenreg(list(melr.brm))
htmlreg(list(melr.brm), file="melrbr.doc", doctype=TRUE, html.tag=TRUE, head.tag=TRUE)

# It may take a couple of minutes to fit the model with MCMCglmm()
library(MCMCglmm)
set.seed(123)
prior = list(R = list(V = 1, nu = 0.002, fix=1), 
             G = list(G1 = list(V = diag(2), nu = 2)))
melr.mc <- MCMCglmm(Profmath1 ~ stlang + csclimat + public, 
                  random =  ~ us(1 + stlang):SCH_ID, 
                  data=els, family = "categorical", prior=prior)                
summary(melr.mc)
save(melr.mc, file = "melrmc.rda")
detach(els)

# Bayesian multilevel ordinal logistic regression models
# It may take around 1 hour or more to fit the model with brm()
library(foreign)
els <- read.dta("C:/CDA/els2002.dta")
attach(els)
els <- els[!is.na(Profmath)&!is.na(stlang)&!is.na(public)&!is.na(sclimate), ]
els$Profmath <- factor(els$Profmath, ordered=TRUE)
els$SCH_ID <- factor(els$SCH_ID)
els$csclimat <- els$sclimate-mean(els$sclimate, na.rm=TRUE)
summary(els$csclimat)

library(brms)
mpo.brm <- brm(Profmath ~ stlang + public + csclimat + (stlang|SCH_ID), 
             data=els, family=cumulative, 
             warmup = 500, iter = 2000, 
             cores = 2, chains = 2, seed=123)
summary(mpo.brm)
print(mpo.brm, digits=3)
coef <- fixef(mpo.brm, summary=TRUE)
coef
exp(fixef(mpo.brm)[, -2])
save(mpo.brm, file = "mpo.rda")
plot(mpo.brm)
conditional_effects(mpo.brm, categorical=TRUE)
detach(els)

# Bayesian multilevel multinomial logistic regression models (see Chapter 14)

# Bayesian multilevel Poisson regression models
library(foreign)
mecount <- read.dta("C:/CDA/mecount.dta")
attach(mecount)
# str(mecount)
# library(sjmisc)
# descr(mecount, byabsen, cmathach, bygender, public, csclimate)

# It may take around 10 minutes or more to compile Stan and fit the model with brm()
library(brms)
mepois.brm <- brm(byabsen ~ cmathach + bygender + public + csclimate + (bygender|SCH_ID), 
                family = poisson, data=mecount, 
                warmup = 500, iter = 3000, 
                cores = 2, chains = 2, seed=123)
summary(mepois.brm)
print(mepois.brm, digits=3)
coef <- fixef(mepois.brm, summary=TRUE)
coef
exp(fixef(mepois.brm)[, -2])
save(mepois.brm, file = "mepoisbrm.rda")
plot(mepois.brm)
conditional_effects(mepois.brm)

# It may take several minutes to fit the model with MCMCglmm()
library(MCMCglmm)
set.seed(123)
prior = list(R = list(V = 1, nu = 0.002), 
             G = list(G1 = list(V = diag(2), nu = 2)))
mepois.mc <- MCMCglmm(byabsen ~ cmathach + bygender + public + csclimate, 
                    random =  ~ us(1 + bygender):SCH_ID, 
                    data=mecount, family = "poisson", prior=prior)
summary(mepois.mc)
autocorr(mepois.mc$Sol)
# It may take several minutes to fit the following model with MCMCglmm()
mepois.mc.2 <- MCMCglmm(byabsen ~ cmathach + bygender + public + csclimate, 
                      random =  ~ us(1 + bygender):SCH_ID, 
                      data=mecount, family = "poisson", prior=prior,
                      burnin = 5000, nitt = 30000, thin = 10)
summary(mepois.mc.2)

# Bayesian multilevel negative binomial regression models
# It may take around 20 minutes or more to fit the model with brm()
menb.brm <- brm(byabsen ~ cmathach + bygender + public + csclimate + (bygender|SCH_ID), 
              family = negbinomial, data=mecount, 
              warmup = 500, iter = 3000, 
              cores = 2, chains = 2, seed=123)
summary(menb.brm)
print(menb.brm, digits=3)
coef <- fixef(menb.brm, summary=TRUE)
coef
exp(fixef(menb.brm)[, -2])
save(menb.brm, file = "menbbrm.rda")
plot(menb.brm)
conditional_effects(menb.brm)
detach(mecount)

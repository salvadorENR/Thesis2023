install.packages(c("bbmle", "brms", "car", "dplyr","ggeffects", "ggplot2",
                   "glmmTMB", "gmodels", "lme4", "lmerTest", "margins",
                   "mclogit", "MCMCglmm", "mlogit", "ordinal", "pastecs", 
                   "pscl", "rcompanion","ResourceSelection","rstanarm",  
                   "sjmisc", "sjstats", "stargazer","texreg", "vcd", "VGAM"))
               
                  

# Install R, RStudio, and Rtools from their websites first.

# If a package is removed from the CRAN repository, we can search and download it 
# from the archive and then install it via the RStudio pull-down menu.
# For example, download mixor_1.0.4.tar.gz from
# https://cran.r-project.org/src/contrib/Archive/mixor/ .
# Then install the mixor package via RStudio menu by going to "Tools" and "Install Packages."

# The foreign, MASS, nlme, and nnet packages are part of the R base distribution, 
# so they do not need to be installed separately. 
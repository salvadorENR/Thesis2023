# Chapter 1 R Script

# The following user-written packages need to be installed first by 
# using install.packages(" ") and then by loading it with library()
# library(dplyr)         
# library(sjmisc)        
# library(car)
# library(ggplot2)

# Section 1.2
# Use c() to create vectors
age <- c(47,72,43,55,50,23,45,71,86,33)
age
gender <- c("male","male","female","female","male","female","male","male","female","female")
gender

# Index a vector
age[5]
gender[3]

# Use matrix() to create matrices
m1 <- matrix(1:8,nrow=4, ncol=2)
m1
m2 <- matrix(1:8,nrow=4, ncol=2, byrow=TRUE)
m2
# Index a matrix
m1[2,1]
m1[4,]
m1[,2]

# Use data.frame() to create a data frame
gss <- data.frame(age, gender)
gss
str(gss)
dim(gss)
names(gss)

# Reference a variable in a data frame
gss$age

# Several functions for descriptive statistics
mean(gss$age)
sd(gss$age)
min(gss$age)
max(gss$age)
length(gss$age)

# Use list() to create a list
list.gss <- list(age, m1, gss)
list.gss
list.gss2 <- list(age=age, matrix1=m1, gssdata=gss)
list.gss2

# Remove all objects
rm(list = ls(all=TRUE))

# Section 1.3
library(foreign)
chp1 <- read.dta("C:/CDA/gss2016-chap1.dta")
attach(chp1)
str(chp1)

# Create a new variable
realinc1 <- realinc/10000
# Create a new variable using mutate()
library(dplyr)
chp1.n <- mutate(chp1, realinc2=realinc/10000)
mean(realinc1, na.rm=TRUE)
mean(chp1.n$realinc2, na.rm=TRUE)

# Recode a variable
chp1$SES <- NA
chp1$SES[chp1$realinc >=0 & chp1$realinc <=  11114] <- 1 
chp1$SES[chp1$realinc >=  11115 & chp1$realinc <= 25739] <- 2 
chp1$SES[chp1$realinc >= 25740 & chp1$realinc <= 38609] <- 3 
chp1$SES[chp1$realinc >= 38610] <- 4 

# Create a factor
chp1$SES <- factor(chp1$SES)
table(chp1$SES)

# Create a factor with labels
chp1$SES <- factor(chp1$SES, labels = c("low SES", "low-middle SES", "upper-middle SES", "high SES"), ordered = TRUE)
table(chp1$SES)

# Recode a variable using recode() in the car package
# install.packages("car")
library(car)
chp1$SES2 <- car::recode(chp1$realinc, "0:11114 = 1; 11115: 25739 = 2; 25740:38609 = 3; 38610:hi = 4; else = NA")
chp1$SES2 <- factor(chp1$SES2)
chp1$SES2 <- factor(chp1$SES, labels = c("low SES", "low-middle SES", "upper-middle SES", "high SES"), ordered = TRUE)
table(chp1$SES2)

# Recode a variable using rec () in the sjmisc package: method 1
library(sjmisc)
chp1$SES3 <- rec(chp1$realinc, rec = "0:11114 = 1; 11115: 25739 = 2; 25740:38609 = 3; 38610:hi = 4; else = NA")
table(chp1$SES3)

# Recode a variable using rec () in the sjmisc package: method 2
chp1.re <- rec(chp1, realinc, rec = "0:11114 = 1; 11115:25739 = 2; 25740:38609 = 3; 38610:hi = 4; else = NA", append = FALSE)
chp1 <- add_columns(chp1.re, chp1, replace = FALSE)
table(chp1.re$realinc_r)

# Create a binary or dummy variable: method 1
chp1$education <- rec(chp1$educ, rec = "min:13.79=0;14:hi=1;else = NA")
table(chp1$education)

# Create a binary or dummy variable: method 2 using dicho() in sjmisc
chp1$education2 <- dicho(chp1$educ, dich.by = 13.79, append = TRUE)
table(chp1$education2)

# Reverse coding with rec()
table(health)
chp1$health.n <- rec(chp1$health, rec = "excellent=1;good=2;fair=3;poor=4;else = NA")
table(chp1$health.n)
chp1$health.rev <- rec(chp1$health.n, rec = "rev") 
table(chp1$health.rev)
str(chp1$health.rev)

# Label a factor
chp1$health.rev <- factor(chp1$health.rev,levels=c(1, 2, 3, 4), labels = c("poor", "fair", "good", "excellent"))
table(chp1$health.rev)
table(chp1$sex)

# Section 1.4
# Data management using the dplyr and sjmisc packages with the pipe operator %>%
library(dplyr)
library(sjmisc)
chp1 %>% select(sex,age) %>% group_by(sex) %>% descr(age)
chp1 %>% select(sex,health) %>% group_by(sex) %>% frq(health)

# Section 1.5
age <- c(47,72,43,55,50,23,45,71,86,33)
gender <- c("male","male","female","female","male","female","male","male","female","female")
gss <- data.frame(age, gender)

# Create a histogram
hist(age)
# Create a histogram with customized arguments
hist(age, main="Histogram of Age in GSS", 
     xlab="Age",xlim=c(20,90),col="lightblue", freq=FALSE)

# Create a bar plot
barplot(table(gender))

# Create a box plot
boxplot(age)
# Create a box plot grouped by gender
boxplot(age ~ gender)

# Create a data frame for a scatterplot
pretest <- c(80,90,68,88,75,71,83,75,95,86,77,90,97,94,89)
posttest <- c(83,95,70,89,80,73,85,78,94,89,77,92,98,95,90)
math <- data.frame(pretest,posttest)

# Create a scatterplot
plot(pretest, posttest)
# Create a scatterplot using ggplot() in ggplot2
library(ggplot2)
ggplot(math, aes(x=pretest, y=posttest)) + geom_point()
ggplot(math, aes(x=pretest, y=posttest)) + geom_line()
ggplot(math, aes(x=pretest, y=posttest)) + geom_point() + stat_smooth(method=lm)

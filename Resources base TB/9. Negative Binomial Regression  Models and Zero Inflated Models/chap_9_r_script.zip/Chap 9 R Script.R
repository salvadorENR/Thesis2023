# Chap 9 R Script
# Remove all objects
rm(list=ls(all=TRUE))

# The following user-written packages need to be installed first 
# Use install.packages(" ") and then load it with library()
# library(MASS)
# library(VGAM)                    # It is already installed for Chapter 4
# library(rcompanion)              # It is already installed for Chapter 3
# library(margins)                 # It is already installed for Chapter 3
# library(ggeffects)               # It is already installed for Chapter 2
# library(texreg)                  # It is already installed for Chapter 4
# library(pscl)

# Import the count dataset
library(foreign)
count <- read.dta("C:/CDA/count.dta")

# Convert variables from integer to numeric so they will work well with ggpredict()
count$educ <- as.numeric(count$educ)
count$wrkfull <- as.numeric(count$wrkfull)
count$maritals <- as.numeric(count$maritals)

attach(count)
str(count)

# Negative binomial regression model with glm.nb() in MASS
library(MASS)
nbr <- glm.nb(vistzoo ~ educ + maritals + female + wrkfull, data=count)
summary(nbr)
alpha <- 1/1.583
alpha
coef(nbr)
confint(nbr)
exp(coef(nbr))
exp(confint(nbr))
cbind(exp(coef(nbr)), exp(confint(nbr)))
exp(coef(nbr))*sqrt(diag(vcov(nbr)))

# marginal effects
library(margins)
marg.nbr <- margins(nbr)
summary(marg.nbr)

# Testing the overall model using the likelihood ratio test
nbr.0 <- glm.nb(vistzoo ~ 1, data=count)
summary(nbr.0)
anova(nbr.0, nbr, test="Chisq")
anova(nbr, update(nbr, ~1), test="Chisq")

# Pseudo R2 with nagelkerke()
library(rcompanion)
nagelkerke(nbr)

# Pseudo R2 with equations
LLM1 <- logLik(nbr)
LL0 <- logLik(nbr.0)
McFadden1 <- 1-(LLM1/LL0)
McFadden1
CS1 <- 1-exp(2*(LL0-LLM1)/902)
CS1
NG1 <- CS1/(1-exp(2*LL0/902))
NG1

# AIC and BIC Statistics
AIC(nbr)
BIC(nbr)

PR.2 <- glm(vistzoo ~ educ + maritals + female + wrkfull, family = poisson, data=count)
AIC(PR.2, nbr)
BIC(PR.2, nbr)

# Presenting the results with stargazer()
library(stargazer)
stargazer(nbr, type="text", align=TRUE, out="nbrmod.txt")
stargazer(nbr, type="html", align=TRUE, out="nbrmod.htm")

# Predicted counts with ggpredict() in ggeffects
library(ggeffects)
nbr.ed <- ggpredict(nbr,terms="educ[12, 14, 16]")
nbr.ed
plot(nbr.ed)

nbr.ew <- ggpredict(nbr, terms=c("educ[12, 14, 16]","wrkfull"))
nbr.ew
plot(nbr.ew)

# Negative binomial regression model with vglm() in VGAM
library(VGAM)
nb.v <- vglm(vistzoo ~ educ + maritals + female + wrkfull, family = negbinomial, data=count)
summary(nb.v)
coef(nb.v, matrix = TRUE)
confint(nb.v, matrix = TRUE)
exp(coef(nb.v, matrix = TRUE))
exp(confint(nb.v, matrix = TRUE))
exp(coef(nb.v))*sqrt(diag(vcov(nb.v)))
exp(.45953)
alpha.v <- 1/1.583
alpha.v
nagelkerke(nb.v)
AIC(nb.v)
BIC(nb.v)

# Model comparison with the likelihood ratio test
library(lmtest)
lrtest(PR.2, nbr)

# ZIP model with zeroinfl() in pscl
# install.packages("pscl")
library(pscl)
zip <- zeroinfl(vistzoo ~ educ + maritals + female + wrkfull | educ+ maritals + female + wrkfull, data=count)
summary(zip)
coef(zip)
confint(zip)
exp(coef(zip))
exp(confint(zip))
cbind(exp(coef(zip)), exp(confint(zip)))
exp(coef(zip))*sqrt(diag(vcov(zip)))

# Pseudo R2 with nagelkerke()
library(rcompanion)
nagelkerke(zip)

# Vuong test
vuong(zip, PR.2)

# ZIP reduced model
zip2 <- zeroinfl(vistzoo ~ educ + maritals + female + wrkfull | wrkfull, data=count)
summary(zip2)
lrtest(zip2, zip)
# Zero-inflated NB model with zeroinfl() in pscl
zinb <- zeroinfl(vistzoo ~ educ + maritals + female + wrkfull | educ + maritals + female + wrkfull, 
               dist="negbin", data=count)
summary(zinb)
coef(zinb)
confint(zinb)
exp(coef(zinb))
exp(confint(zinb))
cbind(exp(coef(zinb)), exp(confint(zinb)))
exp(coef(zinb))*sqrt(diag(vcov(zinb)))
nagelkerke(zinb)

vuong(zinb, nbr)
vuong(nbr, zip2)

# Presenting the results with textreg
library(texreg)
screenreg(list(zip2, zip, zinb))
htmlreg(list(zip2, zip, zinb), file="zipzinb.doc", doctype=TRUE, html.tag=TRUE, head.tag=TRUE)
detach(count)

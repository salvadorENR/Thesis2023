# Chap 14 R Script

# Remove all objects
rm(list = ls(all=TRUE))

# The following user-written packages need to be installed first 
# Use install.packages(" ") and then load it with library()
# library(sjmisc)                  # It is already installed for Chapter 1
# library(mclogit)              
# library(MCMCglmm)  
# library(brms)               
# library(ggeffects)               # It is already installed for Chapter 2
# library(texreg)                  # It is already installed for Chapter 4

# Import the dataset
library(foreign)
nom <- read.dta("C:/CDA/els-nom.dta")
str(nom)

# Recode the outcome variable
library(sjmisc)
nom$prof4 <- rec(nom$Profmath, rec="0:1=1; 2=2; 3=3; 4:5=4; else=NA")

# Create factor variables
nom$prof4 <- factor(nom$prof4)
nom$SCH_ID <- factor(nom$SCH_ID)
attach(nom)
table(prof4)
table(stlang)
table(public)
mean(csclimat)

# Unconditional model/Null model with mblogit() in mclogit
# install.packages("mclogit")
library(mclogit)
mb.null <- mblogit(prof4 ~ 1, random=~1|SCH_ID, data=nom)
summary(mb.null)

coef(mb.null)
coef <- coef(mb.null)
se <- sqrt(diag(vcov(mb.null)))
se
LL <- coef(mb.null)-1.96*se
UL <- coef(mb.null)+1.96*se
coeftab <- cbind(LL, UL)
coeftab
exp(coef(mb.null))
exp(coeftab)
ortab <- cbind(or=exp(coef(mb.null)), ORLL=exp(LL), ORUL=exp(UL))
ortab

# Random-intercept model
mb.2 <- mblogit(prof4 ~ stlang, random=~1|SCH_ID, data=nom)
summary(mb.2)

coef(mb.2)
coef <- coef(mb.2)
se <- sqrt(diag(vcov(mb.2)))
se
LL <- coef(mb.2)-1.96*se
UL <- coef(mb.2)+1.96*se
coeftab <- cbind(LL, UL)
coeftab
exp(coef(mb.2))
exp(coeftab)
ortab <- cbind(or=exp(coef(mb.2)), ORLL=exp(LL), ORUL=exp(UL))
ortab

# Contextual model/Random-intercept model with predictor variables in both levels
mb.3 <- mblogit(prof4 ~ stlang + public + csclimat, random=~1|SCH_ID, data=nom)
summary(mb.3)

coef(mb.3)
coef <- coef(mb.3)
se <- sqrt(diag(vcov(mb.3)))
se
LL <- coef(mb.3)-1.96*se
UL <- coef(mb.3)+1.96*se
coeftab <- cbind(LL, UL)
coeftab

exp(coef(mb.3))
exp(coeftab)
ortab <- cbind(or=exp(coef(mb.3)), ORLL=exp(LL), ORUL=exp(UL))
ortab

# Bayesian multilevel multinomial models with MCMCglmm()
# install.packages("MCMCglmm")
library(MCMCglmm)

# Use set.seed(123) to get replicable results each time with the same seed
set.seed(123)
# Set priors
k <- length(levels(nom$prof4))
I <- diag(k-1)
J <- matrix(rep(1, (k-1)^2), c(k-1, k-1))
priors = list(R = list(fix=1, V=(1/k) * (I + J), n = k - 1), 
              G = list(G1 = list(V = diag(k - 1), n = k - 1)))      

# Model with correlated random effects
# It may take around several minutes to fit the model
mb.mc.3e <- MCMCglmm(prof4 ~ -1 + trait + trait:(stlang + public + csclimat), 
                   random = ~us(trait):SCH_ID, 
                   rcov=~us(trait):units, data=nom, 
                   family = "categorical", prior = priors)
summary(mb.mc.3e)

# Model with uncorrelated random effects
mb.mc.3f <- MCMCglmm(prof4 ~ -1 + trait + trait:(stlang + public + csclimat), 
                   random = ~idh(trait):SCH_ID, 
                   rcov=~us(trait):units, data=nom,
                   family = "categorical", prior = priors)
summary(mb.mc.3f)
autocorr(mb.mc.3f$Sol)

# Bayesian multilevel multinomial models with brm()
library(brms)

# Model with uncorrelated random effects 
# It may take around 40 minutes or more to fit the model
mb.br.3c <- brm(prof4 ~ stlang + public + csclimat  + (1|SCH_ID), data=nom,   
              family=categorical, warmup = 1000, iter = 3000, 
              cores = 2, chains = 2, seed=123)
summary(mb.br.3c)
coef <- fixef(mb.br.3c, summary=TRUE)
coef
exp(fixef(mb.br.3c)[, -2])
save(mb.br.3c, file = "mbbr3c.rda")

# Model with correlated random effects 
# It may take more than 1 hour to fit the model
mb.br.4 <- brm(prof4 ~ stlang + public + csclimat  + (1|p|SCH_ID), data=nom, family=categorical, 
             warmup = 1000, iter = 3000, 
             cores = 2, chains = 2, seed=123)
summary(mb.br.4)
coef <- fixef(mb.br.4, summary=TRUE)
coef
exp(fixef(mb.br.4)[, -2])
save(mb.br.4, file = "mbbr4.rda")

# Model diagnostics with plot()
plot(mb.br.4)

# Conditional effects with conditional_effects()
conditional_effects(mb.br.4, categorical=TRUE, surface=TRUE)

# Predicted probabilities with ggpredict() in ggeffects
library(ggeffects)
mb.br4.pub <- ggpredict(mb.br.4, terms="public")
mb.br4.pub
plot(mb.br4.pub)

# Present the results with texreg()
library(texreg)
extract.brmsfit <- function (model,
                             use.HDI = TRUE,
                             HDI.prob = 0.9,
                             include.random = TRUE,
                             include.rsquared = FALSE,
                             include.nobs = TRUE,
                             include.loo.ic = FALSE,
                             reloo = FALSE,
                             include.waic = FALSE,
                             ...) {
  sf <- summary(model, ...)$fixed
  coefnames <- rownames(sf)
  coefs <- sf[, 1]
  se <- sf[, 2]
  ci.low = sf[, 3]
  ci.up = sf[, 4]
  gof <- numeric()
  gof.names <- character()
  gof.decimal <- logical()
  if (isTRUE(include.random) & isFALSE(!nrow(model$ranef))) {
    sr <- summary(model, ...)$random
    sd.names <- character()
    sd.values <- numeric()
    for (i in 1:length(sr)) {
      sd <- sr[[i]][, 1]
      sd.names <- c(sd.names, paste0("SD: ", names(sr)[[i]], ": ", names(sd)))
      sd.values <- c(sd.values, sd)
    }
    gof <- c(gof, sd.values)
    gof.names <- c(gof.names, sd.names)
    gof.decimal <- c(gof.decimal, rep(TRUE, length(sd.values)))
  }
  if (isTRUE(include.nobs)) {
    n <- stats::nobs(model)
    gof <- c(gof, n)
    gof.names <- c(gof.names, "Num. obs.")
    gof.decimal <- c(gof.decimal, FALSE)
  }
  tr <- createTexreg(coef.names = coefnames,
                     coef = coefs,
                     se = se,
                     ci.low = ci.low,
                     ci.up = ci.up,
                     gof.names = gof.names,
                     gof = gof,
                     gof.decimal = gof.decimal)
  return(tr)
}

setMethod("extract", signature = className("brmsfit", "brm"),
          definition = extract.brmsfit)

screenreg(list(mb.br.3c, mb.br.4))
htmlreg(list(mb.br.3c, mb.br.4), file="mbbr.doc", doctype=TRUE, html.tag=TRUE, head.tag=TRUE)

detach(nom)

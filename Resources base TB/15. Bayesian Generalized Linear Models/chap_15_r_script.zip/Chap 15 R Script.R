# Chap 15 R Script

# Remove all objects
rm(list = ls(all=TRUE))

# The following user-written packages need to be installed first 
# Use install.packages(" ") and then load it with library()
# library(rstanarm)  
# library(brms)                    # It is already installed for Chapter 14
# library(texreg)                  # It is already installed for Chapter 4

# Import GSS 2016 Stata data file
library(foreign)
chp3.lr <- read.dta("C:/CDA/gss2016.dta")
attach(chp3.lr)

# Logistic regression with glm()
LR.2 <- glm(healthy ~ wrkfull + maritals + female + educ, data = chp3.lr, 
          family = binomial(link = "logit"))
summary(LR.2)

# Bayesian logistic regression with rstanarm
library(rstanarm)
LR.2.stan <- stan_glm(healthy ~ wrkfull + maritals + female + educ, data = chp3.lr,
                    family = binomial(link = "logit"))
summary(LR.2.stan)
summary(LR.2.stan, digits=3, prob=c(.025, .5, .975))
prior_summary(LR.2.stan)
coef <- coef(LR.2.stan)
coef
se <- se(LR.2.stan)
se
cbind(coef,se)
posterior_interval(LR.2.stan)
ci <- posterior_interval(LR.2.stan)
cbind(coef,ci)
exp(cbind(coef,ci))
plot(LR.2.stan, "trace")

# Bayesian logistic regression with brms
# It may take several minutes to compile the Stan program and fit the model
library(brms)
LR.2.brm <- brm(healthy ~ wrkfull + maritals + female + educ, data = chp3.lr, 
              family = bernoulli(link = "logit"), 
              warmup = 500, iter = 3000, 
              cores = 2, chains = 2, seed=123)
summary(LR.2.brm)
print(LR.2.brm, digits=3)
coef <- fixef(LR.2.brm, summary=TRUE)
coef
exp(fixef(LR.2.brm)[, -2])
save(LR.2.brm, file = "LR2brm.rda")
plot(LR.2.brm)

library(texreg)
screenreg(list(LR.2.brm))
htmlreg(list(LR.2.brm), file="LR2br.doc", doctype=TRUE, html.tag=TRUE, head.tag=TRUE)

detach(chp3.lr)

# Bayesian ordinal logistic regression with rstanarm 
# Remove all objects
rm(list = ls(all=TRUE))

# Import GSS 2016 Stata data file
library(foreign)
chp4.po <- read.dta("C:/CDA/gss2016.dta")
chp4.po$healthre <- factor(chp4.po$healthre, ordered=TRUE)
attach(chp4.po)

# rstanrarm and brms
# It may take several minutes to fit the model with stan_polr
library(rstanarm)
olr.stan <- stan_polr(healthre ~ maritals + educ + female, data = chp4.po, 
                    method = "logistic", prior = R2(0.2, "mean"), seed = 12345)                  
summary(olr.stan)
summary(olr.stan, digits=3, prob=c(.025, .5, .975))
prior_summary(olr.stan)
coef <- coef(olr.stan)
coef
se <- se(olr.stan)
se
cbind(coef,se)
posterior_interval(olr.stan)
ci <- posterior_interval(olr.stan)
cbind(coef,ci)
exp(cbind(coef,ci))
save(olr.stan, file = "olrstan.rda")

# Bayesian ordinal logistic regression with brms
# It may take several minutes to compile Stan and fit the model
library(brms)
olr.brm <- brm(healthre ~ maritals + educ + female, data = chp4.po, 
             family=cumulative("logit"), 
             warmup = 500, iter = 3000, 
             cores = 2, chains = 2, seed=123)
print(olr.brm, digits=3)
coef <- fixef(olr.brm, summary=TRUE)
coef
exp(fixef(olr.brm)[, -2])
save(olr.brm, file = "olrbrm.rda")
plot(olr.brm)

detach(chp4.po)

# Bayesian multinomial logistic regression with brms
# It may take several minutes to compile Stan and fit the model
rm(list=ls(all=TRUE))
library(foreign)
gss16 <- read.dta("C:/CDA/gss2016-chap2.dta")
gss16$healthre <- factor(gss16$healthre)
attach(gss16)
library(brms)
mulm.brm <- brm(healthre ~ educ + maritals + female + wrkfull, data = gss16, 
              family=categorical, 
              warmup = 500, iter = 3000, 
              cores = 2, chains = 2, seed=123)
summary(mulm.brm)
print(mulm.brm, digits=3)
coef <- fixef(mulm.brm, summary=TRUE)
coef
exp(fixef(mulm.brm)[, -2])
save(mulm.brm, file = "mulmbrm.rda")
plot(mulm.brm)
detach(gss16)

# Bayesian Poisson regression with rstanarm
# Remove all objects
rm(list=ls(all=TRUE))

# Import the count dataset
library(foreign)
count <- read.dta("C:/CDA/count.dta")

# Convert variables from integer to numeric so they will work well with ggpredict()
count$educ <- as.numeric(count$educ)
count$wrkfull <- as.numeric(count$wrkfull)
count$maritals <- as.numeric(count$maritals)

attach(count)
# str(count)

# Multiple-predictor Poisson regression model with glm()
PR.2 <- glm(vistzoo ~ educ + maritals + female + wrkfull, family = poisson, data=count)
summary(PR.2)

# stan_glm() in rstanarm
library(rstanarm)
PR.2.stan <- stan_glm(vistzoo ~ educ + maritals + female + wrkfull, family = poisson, data=count)
summary(PR.2.stan)
summary(PR.2.stan, digits=3, prob=c(.025, .5, .975))
prior_summary(PR.2.stan)
coef <- coef(PR.2.stan)
coef
se <- se(PR.2.stan)
se
cbind(coef,se)
posterior_interval(PR.2.stan)
ci <- posterior_interval(PR.2.stan)
cbind(coef,ci)
exp(cbind(coef,ci))
plot(PR.2.stan, "trace")

# Bayesian Poisson regression with brms 
# It may take a couple of minutes to compile Stan and fit the model.
library(brms)
PR.2.brm <- brm(vistzoo ~ educ + maritals + female + wrkfull, family = poisson, data=count, 
              warmup = 500, iter = 3000, 
              cores = 2, chains = 2, seed=123)
summary(PR.2.brm)
print(PR.2.brm, digits=3)
coef <- fixef(PR.2.brm, summary=TRUE)
coef
exp(fixef(PR.2.brm)[, -2])
save(PR.2.brm, file = "PR2brm.rda")
plot(PR.2.brm)
conditional_effects(PR.2.brm)

# Negative binomial regression model with glm.nb() in MASS
library(MASS)
nbr <- glm.nb(vistzoo ~ educ + maritals + female + wrkfull, data=count)
summary(nbr)

# Bayesian negative binomial models with rstanarm
library(rstanarm)
nbr.stan <- stan_glm(vistzoo ~ educ + maritals + female + wrkfull, family = neg_binomial_2, data=count)
summary(nbr.stan)
summary(nbr.stan, digits=3, prob=c(.025, .5, .975))
prior_summary(nbr.stan)
coef <- coef(nbr.stan)
coef
se <- se(nbr.stan)
se
cbind(coef,se)
posterior_interval(nbr.stan)
ci <- posterior_interval(nbr.stan)
plot(nbr.stan, "trace")

# Bayesian negative binomial models with brms
# It may take a couple of minutes to compile Stan and fit the model.
library(brms)
nbr.brm <- brm(vistzoo ~ educ + maritals + female + wrkfull, family = negbinomial, data=count, 
             warmup = 500, iter = 3000, 
             cores = 2, chains = 2, seed=123)
summary(nbr.brm)
print(nbr.brm, digits=3)
coef <- fixef(nbr.brm, summary=TRUE)
coef
exp(fixef(nbr.brm)[, -2])
save(nbr.brm, file = "nbrbrm.rda")
plot(nbr.brm)

detach(count)
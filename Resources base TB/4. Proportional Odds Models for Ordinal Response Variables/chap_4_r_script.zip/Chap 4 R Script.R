# Chap 4 R Script

# Remove all objects
rm(list = ls(all=TRUE))

# The following user-written packages need to be installed first 
# Use install.packages(" ") and then load it with library()
# library(ordinal)
# library(rcompanion)              # It is already installed for Chapter 3
# library(ggeffects)               # It is already installed for Chapter 2
# library(stargazer)               # It is already installed for Chapter 2
# library(VGAM)     
# library(texreg)

# Import GSS 2016 Stata data file
library(foreign)
chp4.po <- read.dta("C:/CDA/gss2016.dta")
chp4.po$healthre <- factor(chp4.po$healthre, ordered=TRUE)
chp4.po$educ <- as.numeric(chp4.po$educ)
chp4.po$wrkfull <- as.numeric(chp4.po$wrkfull)
chp4.po$maritals <- as.numeric(chp4.po$maritals)
attach(chp4.po) 
str(healthre)

# One-predictor model with the clm() function in ordinal
library(ordinal)
PO.1 <- clm(healthre ~ educ, data = chp4.po)
summary(PO.1)
coef(PO.1)
confint(PO.1)
exp(coef(PO.1))
exp(confint(PO.1))

# Null model with the intercept only
PO.0 <- clm(healthre ~ 1, data = chp4.po)
summary(PO.0)

# Testing the overall model using the likelihood ratio test
anova(PO.0, PO.1)

# Pseudo R2
library(rcompanion)
nagelkerke(PO.1)
LLM <- logLik(PO.1)
LL0 <- logLik(PO.0)
McFadden <- 1-(LLM/LL0)
McFadden
CS <- 1-exp(2*(LL0-LLM)/1873)
CS
NG <- CS/(1-exp(2*LL0/1873))
NG

# PO assumption test
nominal_test(PO.1)

# Multiple-predictor model with the clm() function
PO.2 <- clm(healthre ~ maritals + educ + female, data = chp4.po)
summary(PO.2)
coef(PO.2)
confint(PO.2)
exp(coef(PO.2))
exp(confint(PO.2))

exp(-coef(PO.2))
exp(-confint(PO.2))

# Predicted probabilities with ggpredict() in ggeffects
library(ggeffects)
margins.e <- ggpredict(PO.2, terms="educ[12, 14, 16]")
margins.e
plot(margins.e)

# Predicted probabilities with predict(): Omitted in the chapter
new <- data.frame(educ=c(12,14,16),
                maritals=rep(mean(maritals),3),
                female=rep(mean(female),3))
new
new[,c('pred.prob')] <- predict(PO.2, newdata=new, type="prob", se.fit=TRUE, 
                              interval=TRUE)
new

# Testing the overall model using the likelihood ratio test
anova(PO.0, PO.2)

# Pseudo R2
nagelkerke(PO.2)

# PO assumption test
nominal_test(PO.2)

# Model comparison using the likelihood ratio test
anova(PO.1, PO.2)

# Presenting the results of the clm models using the stargazer package
library(stargazer)
stargazer(PO.1, PO.2, type="text", align=TRUE, out="po2mod.txt")
stargazer(PO.1, PO.2, type="html", align=TRUE, out="po2mod.htm")

# One-predictor model with the vglm() function in VGAM
library(VGAM)
model1 <- vglm(healthre ~ educ, cumulative(parallel = TRUE, reverse = FALSE), 
             data = chp4.po)
summary(model1)
exp(coef(model1, matrix = TRUE))
exp(confint(model1, matrix = TRUE))
cbind(exp(coef(model1)), exp(confint(model1)))
nagelkerke(model1)
AIC(model1)

# Logit coefficients of being at or above a category
model1b <- vglm(healthre ~ educ, cumulative(parallel = TRUE, reverse = TRUE), 
              data = chp4.po)
summary(model1b)
exp(coef(model1b, matrix = TRUE))
exp(confint(model1b, matrix = TRUE))
cbind(exp(coef(model1b)), exp(confint(model1b)))

# Multiple-predictor model with the vglm() function in VGAM
model2 <- vglm(healthre ~ educ + maritals + female, 
             cumulative(parallel = TRUE, reverse = FALSE),data = chp4.po)
                                                              
summary(model2)
coef(model2, matrix = TRUE)
confint(model2, matrix = TRUE)
exp(coef(model2, matrix = TRUE))
exp(confint(model2, matrix = TRUE))
cbind(exp(coef(model2)), exp(confint(model2)))
AIC(model2)
# nagelkerke(model2)

# Predicted probabilities with predict()
new1 <- data.frame(educ=c(12,14,16),
                 maritals=rep(mean(maritals),3),
                 female=rep(mean(female),3))
new1
new1[,c('pred.prob')]<-predict(model2, newdata=new1, type="response")
new1

# Predicted probabilities with ggpredict() in ggeffects
library(ggeffects)
margins.e2.ciNA <- ggpredict(model2, terms="educ[12, 14, 16]", ci=NA)
margins.e2.ciNA
plot(margins.e2.ciNA)

margins.e2 <- ggpredict(model2, terms="educ[12, 14, 16]")
margins.e2
as.data.frame(margins.e2)
plot(margins.e2)

# Logit coefficients of being at or above a category with reverse = TRUE  
model2b <- vglm(healthre ~ educ + maritals + female, 
              cumulative(parallel = TRUE, reverse = TRUE), data = chp4.po)
summary(model2b)
coef(model2b, matrix = TRUE)
confint(model2b, matrix = TRUE)
exp(coef(model2b, matrix = TRUE))
exp(confint(model2b, matrix = TRUE))
cbind(exp(coef(model2b)), exp(confint(model2b)))
# AIC(model2b)

# Testing the Overall Model Using the Likelihood Ratio Test: Omitted in the chapter
model0 <- vglm(healthre ~ 1, cumulative(parallel = TRUE, reverse = FALSE), 
             data = chp4.po)
summary(model0)
lrtest(model0, model1)
lrtest(model0, model2)

# PO assumption test
model2c <- vglm(healthre ~ educ + maritals + female, 
              cumulative(parallel = FALSE, reverse = FALSE),data = chp4.po)
lrtest(model2, model2c)

# Model comparison with the likelihood ratio test
lrtest(model1, model2)

# Presenting the results of the vglm Models using the texreg package
library(texreg)          
screenreg(list(model1, model2))
htmlreg(list(model1, model2), file="chap4po.doc", doctype=TRUE, 
        html.tag=TRUE, head.tag=TRUE)
detach(chp4.po)
# Chap 5 R Script
# Remove all objects
rm(list=ls(all=TRUE))

# The following user-written packages need to be installed first 
# Use install.packages(" ") and then load it with library()
# library(VGAM)                    # It is already installed for Chapter 4
# library(rcompanion)              # It is already installed for Chapter 3
# library(ggeffects)               # It is already installed for Chapter 2
# library(texreg)                  # It is already installed for Chapter 4

# Import the GSS 2016 data
library(foreign)
chp5.gpo <- read.dta("C:/CDA/gss2016.dta")
chp5.gpo$healthre <- factor(chp5.gpo$healthre, ordered=TRUE)
chp5.gpo$educ <- as.numeric(chp5.gpo$educ)
chp5.gpo$wrkfull <- as.numeric(chp5.gpo$wrkfull)
chp5.gpo$maritals <- as.numeric(chp5.gpo$maritals)
attach(chp5.gpo)

# PO model with vglm() in VGAM
library(VGAM)
mod.po <- vglm(healthre ~ educ + maritals + female + wrkfull, 
             cumulative(parallel = TRUE, reverse = FALSE), data = chp5.gpo)
summary(mod.po)

# GPO model with vglm() in VGAM
mod.gpo <- vglm(healthre ~ educ + maritals + female + wrkfull, 
              cumulative(parallel = FALSE, reverse = FALSE), data = chp5.gpo)

# Using the lrtest() function to test the PO assumption
lrtest(mod.po, mod.gpo)

summary(mod.gpo)
coef(mod.gpo, matrix = TRUE)
confint(mod.gpo, matrix = TRUE)
exp(coef(mod.gpo, matrix = TRUE))
exp(confint(mod.gpo, matrix = TRUE))
cbind(exp(coef(mod.gpo)), exp(confint(mod.gpo)))

# Testing the overall model using the likelihood ratio test
gpomodel0 <- vglm(healthre ~ 1, cumulative(parallel = TRUE, reverse = FALSE))
summary(gpomodel0)
lrtest(gpomodel0, mod.gpo)

# Pseudo R2
library(rcompanion)
nagelkerke(mod.gpo)
AIC(mod.gpo)
BIC(mod.gpo)

# Predicted probabilities with ggpredict() in ggeffects
library(ggeffects)
prob.e <- ggpredict(mod.gpo, terms="educ[12, 14, 16]", ci=NA)
prob.e
plot(prob.e)

# Predicted cumulative probabilities with ggpredict() in ggeffects
cumprob.e <- ggpredict(mod.gpo, terms="educ[12, 14, 16]")
cumprob.e
as.data.frame(cumprob.e)
plot(cumprob.e)

# Logit coefficients of being at or above a category with reverse = TRUE
mod.gpo2 <- vglm(healthre ~ educ + maritals + female + wrkfull, 
               cumulative(parallel = FALSE, reverse = TRUE), data = chp5.gpo)
summary(mod.gpo2)
coef(mod.gpo2, matrix = TRUE)
confint(mod.gpo2, matrix = TRUE)
exp(coef(mod.gpo2, matrix = TRUE))
exp(confint(mod.gpo2, matrix = TRUE))
cbind(exp(coef(mod.gpo2)), exp(confint(mod.gpo2)))
AIC(mod.gpo2)
BIC(mod.gpo2)
nagelkerke(mod.gpo2)

# PPO model with vglm() in VGAM
mod.ppo <- vglm(healthre ~ educ + maritals + female + wrkfull, 
              cumulative(parallel = FALSE ~ wrkfull, reverse = FALSE), 
              data = chp5.gpo)
summary(mod.ppo)
coef(mod.ppo, matrix = TRUE)
confint(mod.ppo, matrix = TRUE)
exp(coef(mod.ppo, matrix = TRUE))
exp(confint(mod.ppo, matrix = TRUE))
cbind(exp(coef(mod.ppo)), exp(confint(mod.ppo)))

# Testing the overall model using the likelihood ratio test
lrtest(gpomodel0, mod.ppo)

# Pseudo R2
nagelkerke(mod.ppo)
AIC(mod.ppo)
BIC(mod.ppo)

# Predicted probabilities with ggpredict() in ggeffects
prob.e2 <- ggpredict(mod.ppo, terms="educ[12, 14, 16]", ci=NA)
prob.e2
plot(prob.e2)

# Predicted cumulative probabilities with ggpredict() in ggeffects
cumprob.e2 <- ggpredict(mod.ppo, terms="educ[12, 14, 16]")
cumprob.e2
as.data.frame(cumprob.e2)
plot(cumprob.e2)

# Logit coefficients of being at or above a category with reverse = TRUE
mod.ppo2 <- vglm(healthre ~ educ + maritals + female + wrkfull, 
               cumulative(parallel = FALSE ~ wrkfull, reverse = TRUE), data = chp5.gpo)
summary(mod.ppo2)
coef(mod.ppo2, matrix = TRUE)
exp(coef(mod.ppo2, matrix = TRUE))
exp(confint(mod.ppo2, matrix = TRUE))
cbind(exp(coef(mod.ppo2)), exp(confint(mod.ppo2)))
AIC(mod.ppo2)
BIC(mod.ppo)

# Presenting the results of the vglm Models using the texreg package
library(texreg)
screenreg(mod.ppo)
htmlreg(list(mod.ppo), file="chap5ppo.doc", doctype=TRUE, html.tag=TRUE, head.tag=TRUE)

detach(chp5.gpo)

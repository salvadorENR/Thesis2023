# Chap 6 R Script
# Remove all objects
rm(list=ls(all=TRUE))

# The following user-written packages need to be installed first 
# Use install.packages(" ") and then load it with library()
# library(VGAM)                    # It is already installed for Chapter 4
# library(rcompanion)              # It is already installed for Chapter 3
# library(ggeffects)               # It is already installed for Chapter 2
# library(texreg)                  # It is already installed for Chapter 4

# Section I
# Import GSS 2016 data
library(foreign)
chp6.cr <- read.dta("C:/CDA/gss2016.dta")
chp6.cr$healthre <- factor(chp6.cr$healthre, ordered=TRUE)
chp6.cr$educ <- as.numeric(chp6.cr$educ)
chp6.cr$wrkfull <- as.numeric(chp6.cr$wrkfull)
chp6.cr$maritals <- as.numeric(chp6.cr$maritals)
attach(chp6.cr)

# CR model with vglm() in VGAM
library(VGAM)
crmodel2 <- vglm(healthre ~ educ + maritals + female + wrkfull, 
               sratio(parallel = TRUE, reverse = FALSE))
summary(crmodel2)
coef(crmodel2, matrix = TRUE)
confint(crmodel2, matrix = TRUE)
exp(coef(crmodel2, matrix = TRUE))
exp(confint(crmodel2, matrix = TRUE))
cbind(exp(coef(crmodel2)), exp(confint(crmodel2)))

exp(-coef(crmodel2, matrix = TRUE))
exp(-confint(crmodel2, matrix = TRUE))
cbind(exp(-coef(crmodel2)), exp(-confint(crmodel2)))

# Testing the overall model using the likelihood ratio test
crmodel0 <- vglm(healthre ~ 1, sratio(parallel = TRUE, reverse = FALSE))
summary(crmodel0)
lrtest(crmodel0, crmodel2)

# Pseudo R2
library(rcompanion)
nagelkerke(crmodel2)

# AIC and BIC Statistics
AIC(crmodel2)
BIC(crmodel2)

# Predicted probabilities with ggpredict() in ggeffects
library(ggeffects)
pr.cr2m <- ggpredict(crmodel2, terms="educ[12, 14, 16]", ci=NA)
pr.cr2m
plot(pr.cr2m)

pr.cr2 <- ggpredict(crmodel2, terms=c("educ[12, 14, 16]","maritals"), ci=NA)
pr.cr2
plot(pr.cr2)

# CR model with non-proportional odds
crmodel3 <- vglm(healthre ~ educ + maritals + female + wrkfull, 
               sratio(parallel = FALSE, reverse = FALSE))
summary(crmodel3)
coef(crmodel3, matrix = TRUE)
confint(crmodel3, matrix = TRUE)
exp(coef(crmodel3, matrix = TRUE))
exp(confint(crmodel3, matrix = TRUE))
cbind(exp(coef(crmodel3)), exp(confint(crmodel3)))

exp(-coef(crmodel3, matrix = TRUE))
exp(-confint(crmodel3, matrix = TRUE))
cbind(exp(-coef(crmodel3)), exp(-confint(crmodel3)))

lrtest(crmodel0, crmodel3)
AIC(crmodel3)
BIC(crmodel3)

# Model comparison with the likelihood ratio test
lrtest(crmodel2, crmodel3)

# Single-predictor CR model
crmodel1 <- vglm(healthre ~ educ, sratio(parallel = TRUE, reverse = FALSE))

# Presenting the results of the CR Models using the texreg package
library(texreg)
screenreg(list(crmodel1, crmodel2))
htmlreg(list(crmodel1, crmodel2), file="chap6cr.doc", 
        doctype=TRUE, html.tag=TRUE, head.tag=TRUE)

# Section II
# AC model with vglm() in VGAM
acmodel2 <- vglm(healthre ~ educ + maritals + female + wrkfull, 
               acat(parallel = TRUE, reverse = FALSE))
summary(acmodel2)
coef(acmodel2, matrix = TRUE)
confint(acmodel2, matrix = TRUE)
exp(coef(acmodel2, matrix = TRUE))
exp(confint(acmodel2, matrix = TRUE))
cbind(exp(coef(acmodel2)), exp(confint(acmodel2)))

exp(-coef(acmodel2, matrix = TRUE))
exp(-confint(acmodel2, matrix = TRUE))
cbind(exp(-coef(acmodel2)), exp(-confint(acmodel2)))

# Testing the overall model using the likelihood ratio test
acmodel0 <- vglm(healthre ~ 1, acat(parallel = TRUE, reverse = FALSE))
summary(acmodel0)
lrtest(acmodel0, acmodel2)

# Pseudo R2
nagelkerke(acmodel2)

# AIC and BIC Statistics
AIC(acmodel2)
BIC(acmodel2)

# Section III
# SL model with vglm() in VGAM
slmodel2 <- rrvglm(healthre ~ educ + maritals + female + wrkfull, multinomial, rank=1)
summary(slmodel2)
coef(slmodel2, matrix = TRUE)
exp(coef(slmodel2, matrix = TRUE))
exp(-coef(slmodel2, matrix = TRUE))

detach(chp6.cr)

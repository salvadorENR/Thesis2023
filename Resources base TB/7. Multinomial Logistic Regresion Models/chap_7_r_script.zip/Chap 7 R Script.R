# Chap 7 R Script
# Remove all objects
rm(list=ls(all=TRUE))

# The following user-written packages need to be installed first 
# Use install.packages(" ") and then load it with library()
# library(VGAM)                    # It is already installed for Chapter 4
# library(rcompanion)              # It is already installed for Chapter 3
# library(ggeffects)               # It is already installed for Chapter 2
# library(texreg)                  # It is already installed for Chapter 4
# library(nnet)
# library(mlogit)

# Import the GSS 2016 data
library(foreign)
chp7.mul <- read.dta("C:/CDA/gss2016.dta")
chp7.mul$healthre <- factor(chp7.mul$healthre)
chp7.mul$educ <- as.numeric(chp7.mul$educ)
chp7.mul$wrkfull <- as.numeric(chp7.mul$wrkfull)
chp7.mul$maritals <- as.numeric(chp7.mul$maritals)
attach(chp7.mul)

# One-predictor multinomial logistic regression model with vglm() in VGAM
library(VGAM)
mulmodel1 <- vglm(healthre ~ educ, multinomial(refLevel = 1), data=chp7.mul)
summary(mulmodel1)
coef(mulmodel1, matrix = TRUE)
confint(mulmodel1, matrix = TRUE)
exp(coef(mulmodel1, matrix = TRUE))
exp(confint(mulmodel1, matrix = TRUE))
cbind(exp(coef(mulmodel1)), exp(confint(mulmodel1)))

# Testing the overall model using the likelihood ratio test
mulmodel0 <- vglm(healthre ~ 1, multinomial(refLevel = 1), data=chp7.mul)
summary(mulmodel0)
lrtest(mulmodel0, mulmodel1)

# Pseudo R2 with nagelkerke()
library(rcompanion)
nagelkerke(mulmodel1)

# Pseudo R2 with equations
LLM1 <- logLik(mulmodel1)
LL0 <- logLik(mulmodel0)
McFadden1 <- 1-(LLM1/LL0)
McFadden1
CS1 <- 1-exp(2*(LL0-LLM1)/1873)
CS1
NG1 <- CS1/(1-exp(2*LL0/1873))
NG1

# AIC and BIC Statistics
AIC(mulmodel1)
BIC(mulmodel1)

# Multiple-predictor multinomial logistic regression model with vglm() in VGAM
mulmodel2 <- vglm(healthre ~ educ + maritals + female + wrkfull,
                multinomial(refLevel = 1), data=chp7.mul)
summary(mulmodel2)
coef(mulmodel2, matrix = TRUE)
confint(mulmodel2, matrix = TRUE)
exp(coef(mulmodel2, matrix = TRUE))
exp(confint(mulmodel2, matrix = TRUE))
cbind(exp(coef(mulmodel2)), exp(confint(mulmodel2)))

# Testing the overall model using the likelihood ratio test
lrtest(mulmodel0, mulmodel2)

# Pseudo R2 with nagelkerke()
nagelkerke(mulmodel2)

# Pseudo R2 with equations
LLM2 <- logLik(mulmodel2)
McFadden2 <- 1-(LLM2/LL0)
McFadden2
CS2 <- 1-exp(2*(LL0-LLM2)/1873)
CS2
NG2 <- CS2/(1-exp(2*LL0/1873))
NG2

# AIC and BIC Statistics
AIC(mulmodel2)
BIC(mulmodel2)

# Model comparison with the likelihood ratio test
lrtest(mulmodel1, mulmodel2)

# Predicted probabilities with ggpredict() in ggeffects
library(ggeffects)
pr.mul2m <- ggpredict(mulmodel2, terms="educ[12, 14, 16]", ci=NA)
pr.mul2m
plot(pr.mul2m)

pr.mul2 <- ggpredict(mulmodel2, terms=c("educ[12, 14, 16]","maritals"), ci=NA)
pr.mul2
plot(pr.mul2)

# Presenting the results of the multinomial logistic Models using the texreg package
library(texreg)
screenreg(list(mulmodel1, mulmodel2))
htmlreg(list(mulmodel1, mulmodel2), file="chap7mul.doc", 
        doctype=TRUE, html.tag=TRUE, head.tag=TRUE)

# Using multinom() in nnet
library(nnet)
mulmodel2b <- multinom(healthre ~ educ + maritals + female + wrkfull, data=chp7.mul)
summary(mulmodel2b)
coef(mulmodel2b)
z <- summary(mulmodel2b)$coefficients/summary(mulmodel2b)$standard.errors
z
p <- (1-pnorm(abs(z),0,1))*2
p
exp(coef(mulmodel2b))
exp(confint(mulmodel2b))

# Using mlogit() in mlogit
library(mlogit)
chp7 <- mlogit.data(chp7.mul, choice="healthre", shape="wide")
mulmodel2c <- mlogit(healthre ~ 1 | educ + maritals + female + wrkfull, 
                   reflevel = 1, data=chp7)
summary(mulmodel2c)
coef(mulmodel2c)
confint(mulmodel2c)
exp(coef(mulmodel2c))
exp(confint(mulmodel2c))
cbind(exp(coef(mulmodel2c)), exp(confint(mulmodel2c)))

detach(chp7.mul)
